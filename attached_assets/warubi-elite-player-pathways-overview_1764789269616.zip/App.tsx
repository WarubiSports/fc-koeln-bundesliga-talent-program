import React, { useState } from 'react';
import { VideoCard } from './components/ui/VideoCard';
import { ChevronRight, ClipboardList } from 'lucide-react';
import { IntakeModal } from './components/ui/IntakeModal';
import { Credibility } from './components/sections/Credibility';
import { Ticker } from './components/sections/Ticker';

// Reusable Media Card Component matching the reference style
const PathwayCard = ({ 
  category,
  title, 
  subtitle, 
  children,
  onClick
}: { 
  category: string;
  title: string; 
  subtitle: string; 
  children?: React.ReactNode;
  onClick?: () => void;
}) => {
  return (
    <div 
      className="bg-white rounded-3xl overflow-hidden border border-neutral-100 shadow-[0_2px_8px_rgba(0,0,0,0.04)] hover:shadow-[0_12px_24px_rgba(0,0,0,0.08)] hover:-translate-y-1 transition-all duration-300 flex flex-col h-full group w-full cursor-default"
      onClick={onClick}
    >
      {/* Media Top Section - "The Card" look */}
      <div className="w-full relative bg-neutral-100">
        {children}
      </div>

      {/* Text Content Bottom Section */}
      <div className="p-6 md:p-8 flex flex-col flex-grow relative bg-white">
        
        {/* Category Pill */}
        <div className="mb-4">
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-widest bg-red-50 text-red-600/80">
            {category}
          </span>
        </div>

        {/* Title & Subtitle */}
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-neutral-900 mb-2 leading-tight">
            {title}
          </h2>
          <p className="text-neutral-500 font-medium text-sm leading-relaxed">
            {subtitle}
          </p>
        </div>

        {/* Action Area */}
        <div className="mt-auto pt-6 border-t border-neutral-100 flex items-center justify-between">
          <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wider group-hover:text-neutral-900 transition-colors">
            Explore Pathway
          </span>
          <div className="w-8 h-8 rounded-full bg-neutral-50 flex items-center justify-center group-hover:bg-red-500 transition-colors duration-300">
            <ChevronRight size={16} className="text-neutral-400 group-hover:text-white transition-colors" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#F5F7FA] flex flex-col font-sans text-neutral-900 selection:bg-red-100 relative">
      
      <IntakeModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />

      {/* Dot Pattern Background */}
      <div className="absolute inset-0 opacity-[0.4] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#CBD5E1 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>

      {/* Header */}
      <header className="relative pt-20 pb-12 px-6 text-center max-w-4xl mx-auto z-10">
        <h1 className="text-4xl md:text-6xl font-black tracking-tight text-neutral-900 mb-4 uppercase">
          WARUBI <span className="text-red-600">Elite</span> <br className="hidden md:block"/> Player Pathways
        </h1>
        <p className="text-lg md:text-xl text-neutral-500 font-medium max-w-2xl mx-auto mb-8">
          Choose a pathway to explore real examples and stories.
        </p>

        {/* Intake Form Trigger Button */}
        <button 
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center gap-2 px-6 py-3 bg-white border border-neutral-200 shadow-sm rounded-full text-neutral-900 font-semibold hover:shadow-md hover:border-red-200 hover:text-red-600 transition-all duration-300 group"
        >
          <ClipboardList size={18} className="text-neutral-400 group-hover:text-red-500 transition-colors" />
          <span>Find your perfect pathway</span>
        </button>
      </header>

      {/* Main Grid */}
      <main className="relative flex-grow w-full max-w-[1400px] mx-auto px-4 md:px-8 pb-20 z-10">
        
        {/* Trust & Credibility Section */}
        <Credibility />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
          
          {/* 1. College Pathway */}
          <PathwayCard 
            category="Pathway 01"
            title="College Pathway" 
            subtitle="Realistic placement to NCAA and NAIA universities with long-term development."
          >
            <VideoCard 
              title="Avery - College Pathway Story"
              caption="From Europe to US college"
              thumbnailUrl="https://img.youtube.com/vi/26iGcbEljI8/maxresdefault.jpg"
              youtubeId="26iGcbEljI8"
              hideText={true}
              className="rounded-none"
            />
          </PathwayCard>

          {/* 2. Development Europe */}
          <PathwayCard 
            category="Pathway 02"
            title="Development in Europe" 
            subtitle="Full season training and playing opportunities in top German environments."
          >
            <VideoCard 
              title="ITP Cologne"
              caption="Full season development example"
              thumbnailUrl="https://img.youtube.com/vi/dyiMulYAzdo/maxresdefault.jpg"
              youtubeId="dyiMulYAzdo"
              hideText={true}
              className="rounded-none"
            />
          </PathwayCard>

          {/* 3. Coaching Pathway */}
          <PathwayCard 
            category="Pathway 03"
            title="UEFA & German FA Coaching" 
            subtitle="Official licenses and hands-on coaching experience in German academies."
          >
            <VideoCard 
              title="UEFA Coaching Story"
              caption="How coaches use WARUBI to progress"
              thumbnailUrl="https://img.youtube.com/vi/kP3KuKfHYKs/maxresdefault.jpg"
              youtubeId="kP3KuKfHYKs"
              hideText={true}
              className="rounded-none"
            />
          </PathwayCard>

          {/* 4. Exposure Pathway */}
          <PathwayCard 
            category="Pathway 04"
            title="Exposure Events" 
            subtitle="High-level showcases and ID camps for direct scouting opportunities."
          >
            <VideoCard 
              title="Showcase Cologne"
              caption="High level scouting event in Cologne"
              thumbnailUrl="https://img.youtube.com/vi/BPwV72OJbdE/maxresdefault.jpg"
              youtubeId="BPwV72OJbdE"
              hideText={true}
              className="rounded-none"
            />
          </PathwayCard>

        </div>
      </main>
      
      {/* Live Ticker */}
      <Ticker />

      {/* Minimal Footer */}
      <footer className="relative py-12 text-center border-t border-neutral-200 bg-white z-10">
        <div className="flex flex-col items-center gap-4">
          <p className="text-sm font-medium text-neutral-400 uppercase tracking-widest">
            Start your journey
          </p>
          <a 
            href="mailto:contact@warubi-sports.com" 
            className="text-lg font-bold text-neutral-900 border-b-2 border-transparent hover:border-red-500 transition-colors"
          >
            Contact WARUBI
          </a>
        </div>
      </footer>
    </div>
  );
}
