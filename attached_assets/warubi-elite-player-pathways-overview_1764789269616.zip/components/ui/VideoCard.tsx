import React, { useState } from 'react';
import { Play } from 'lucide-react';

interface VideoCardProps {
  title: string;
  caption: string;
  thumbnailUrl: string;
  youtubeId?: string;
  placeholder?: boolean;
  className?: string;
  hideText?: boolean;
}

export const VideoCard: React.FC<VideoCardProps> = ({ 
  title, 
  caption, 
  thumbnailUrl, 
  youtubeId, 
  placeholder = false,
  className = "",
  hideText = false
}) => {
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlay = (e: React.MouseEvent) => {
    if (youtubeId && !placeholder) {
      e.preventDefault();
      e.stopPropagation();
      setIsPlaying(true);
    }
  };

  return (
    <div 
      className={`group/video flex flex-col gap-4 w-full relative ${className} ${youtubeId && !placeholder ? 'cursor-pointer' : ''}`} 
      onClick={handlePlay}
    >
      <div className="relative w-full aspect-video bg-neutral-100 overflow-hidden shadow-sm transition-shadow duration-500 rounded-none md:rounded-t-2xl lg:rounded-none isolate">
        {isPlaying && youtubeId ? (
          <iframe
            className="w-full h-full object-cover relative z-30"
            src={`https://www.youtube.com/embed/${youtubeId}?autoplay=1&rel=0&modestbranding=1&playsinline=1`}
            title={title}
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        ) : (
          <button
            type="button"
            className="absolute inset-0 w-full h-full p-0 border-0 focus:outline-none text-left z-20"
            onClick={handlePlay}
            aria-label={youtubeId ? `Play video: ${title}` : title}
            disabled={!youtubeId || placeholder}
          >
            {/* Image Layer */}
            <div className="absolute inset-0 z-0">
              <img 
                src={thumbnailUrl} 
                alt="" 
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover/video:scale-105 will-change-transform" 
              />
              {/* Subtle Overlay */}
              <div className="absolute inset-0 bg-neutral-900/10 group-hover/video:bg-neutral-900/20 transition-colors duration-500" />
            </div>

            {/* Center Play Button - Modern & Clean */}
            {!placeholder && youtubeId && (
              <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
                <div className="
                  w-16 h-16 rounded-full 
                  bg-white/90 backdrop-blur-sm
                  flex items-center justify-center 
                  shadow-lg
                  group-hover/video:scale-110 group-hover/video:bg-white
                  transition-all duration-300 ease-out
                ">
                  <Play className="w-6 h-6 text-neutral-900 ml-1 fill-neutral-900" />
                </div>
              </div>
            )}

            {/* Badges */}
            {placeholder && (
              <div className="absolute top-4 left-4 z-10 pointer-events-none">
                <span className="inline-block px-3 py-1 bg-white/90 backdrop-blur-md text-neutral-900 text-[10px] font-bold uppercase tracking-wider rounded-full shadow-sm">
                  Coming Soon
                </span>
              </div>
            )}
          </button>
        )}
      </div>

      {/* Optional Text Content */}
      {!hideText && (
        <div className="space-y-1.5 pr-4 pointer-events-none">
          <h3 className="text-lg font-medium text-neutral-900 group-hover/video:text-neutral-600 transition-colors duration-300">
            {title}
          </h3>
          <p className="text-sm text-neutral-500 font-light leading-relaxed">
            {caption}
          </p>
        </div>
      )}
    </div>
  );
};
