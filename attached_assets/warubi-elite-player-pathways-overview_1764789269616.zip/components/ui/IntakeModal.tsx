import React, { useState } from 'react';
import { X, Check, ChevronRight, Wand2 } from 'lucide-react';

interface IntakeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const IntakeModal: React.FC<IntakeModalProps> = ({ isOpen, onClose }) => {
  const [step, setStep] = useState(1); // 1 = Input, 2 = Success
  const [formData, setFormData] = useState({
    role: 'Player',
    name: '',
    email: '',
    age: '',
    goals: [] as string[],
    currentLevel: '',
    budget: '',
    gradYear: '',
    gapYear: false,
  });

  if (!isOpen) return null;

  const fillDemoData = () => {
    setFormData({
      role: 'Player',
      name: 'Julian Tester',
      email: 'julian.test@warubi.com',
      age: '18',
      goals: ['US College Soccer', 'Pro Academy in Europe'],
      currentLevel: 'U19 Regional League',
      budget: 'flexible',
      gradYear: '2025',
      gapYear: true,
    });
  };

  const handleGoalToggle = (goal: string) => {
    setFormData(prev => ({
      ...prev,
      goals: prev.goals.includes(goal) 
        ? prev.goals.filter(g => g !== goal)
        : [...prev.goals, goal]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, send data here
    setTimeout(() => setStep(2), 500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-neutral-900/60 backdrop-blur-sm transition-opacity" 
        onClick={onClose}
      />

      {/* Modal Content */}
      <div className="relative bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-300 flex flex-col max-h-[90vh]">
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 p-2 rounded-full hover:bg-neutral-100 transition-colors z-10 text-neutral-500 hover:text-neutral-900"
        >
          <X size={20} />
        </button>

        {step === 1 ? (
          <div className="flex flex-col overflow-y-auto">
            <div className="p-8 md:p-10 pb-0 flex justify-between items-start shrink-0">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h2 className="text-2xl md:text-3xl font-bold text-neutral-900">
                    Find your perfect pathway
                  </h2>
                  <button 
                    onClick={fillDemoData}
                    className="p-1.5 text-neutral-200 hover:text-red-500 hover:bg-red-50 rounded-md transition-all"
                    title="Fill Demo Data"
                  >
                    <Wand2 size={16} />
                  </button>
                </div>
                <p className="text-neutral-500 font-light">
                  Tell us a bit about yourself so we can recommend the best route for your development.
                </p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="p-8 md:p-10 space-y-8">
              
              {/* Role Selection */}
              <div className="space-y-3">
                <label className="text-sm font-semibold uppercase tracking-wider text-neutral-400">I am a</label>
                <div className="flex gap-4">
                  {['Player', 'Coach', 'Parent'].map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setFormData({...formData, role: r})}
                      className={`flex-1 py-3 rounded-xl border font-medium transition-all duration-200 ${
                        formData.role === r 
                          ? 'border-red-600 bg-red-50 text-red-700' 
                          : 'border-neutral-200 hover:border-neutral-300 text-neutral-600'
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>

              {/* Contact Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-neutral-900">Name</label>
                  <input 
                    type="text" 
                    placeholder="Your Full Name"
                    required
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-neutral-900">Email</label>
                  <input 
                    type="email" 
                    placeholder="you@example.com"
                    required
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                  />
                </div>
              </div>

              {/* Basic Info Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-neutral-900">Age</label>
                  <input 
                    type="number" 
                    placeholder="e.g. 17"
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all"
                    value={formData.age}
                    onChange={(e) => setFormData({...formData, age: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-neutral-900">Graduation Year</label>
                  <input 
                    type="text" 
                    placeholder="e.g. 2025"
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all"
                    value={formData.gradYear}
                    onChange={(e) => setFormData({...formData, gradYear: e.target.value})}
                  />
                </div>
              </div>

              {/* Goals (Multi-select) */}
              <div className="space-y-3">
                <label className="text-sm font-medium text-neutral-900">Primary Goals <span className="text-neutral-400 font-normal">(Select all that apply)</span></label>
                <div className="flex flex-wrap gap-3">
                  {['US College Soccer', 'Pro Academy in Europe', 'Semi-Pro Level', 'Coaching License', 'Gap Year Experience'].map((goal) => (
                    <button
                      key={goal}
                      type="button"
                      onClick={() => handleGoalToggle(goal)}
                      className={`px-4 py-2 rounded-full text-sm font-medium border transition-all duration-200 ${
                        formData.goals.includes(goal)
                          ? 'bg-neutral-900 text-white border-neutral-900'
                          : 'bg-white text-neutral-600 border-neutral-200 hover:border-neutral-400'
                      }`}
                    >
                      {goal}
                    </button>
                  ))}
                </div>
              </div>

              {/* Current Level */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-neutral-900">Current Level / League</label>
                <input 
                  type="text" 
                  placeholder="e.g. U19 Bundesliga, Regional League, High School Varsity..."
                  className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all"
                  value={formData.currentLevel}
                  onChange={(e) => setFormData({...formData, currentLevel: e.target.value})}
                />
              </div>

              {/* Investment / Budget */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-neutral-900">Development Investment Preference</label>
                <div className="relative">
                  <select 
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-4 py-3 appearance-none focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all text-neutral-700"
                    value={formData.budget}
                    onChange={(e) => setFormData({...formData, budget: e.target.value})}
                  >
                    <option value="" disabled>Select the best fit...</option>
                    <option value="scholarship">Seeking full scholarship opportunities</option>
                    <option value="flexible">Flexible budget for quality development</option>
                    <option value="premium">Open to premium, full-service programs</option>
                    <option value="unsure">Not sure yet / Need guidance</option>
                  </select>
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-neutral-400">
                    <ChevronRight size={16} className="rotate-90" />
                  </div>
                </div>
                <p className="text-xs text-neutral-400 mt-1">This helps us understand which program types are realistic options for you.</p>
              </div>

              {/* Gap Year Toggle */}
              <div className="flex items-center gap-3 p-4 border border-neutral-100 rounded-xl bg-neutral-50/50">
                <div 
                  className={`w-12 h-6 rounded-full p-1 cursor-pointer transition-colors duration-300 ${formData.gapYear ? 'bg-green-500' : 'bg-neutral-300'}`}
                  onClick={() => setFormData({...formData, gapYear: !formData.gapYear})}
                >
                  <div className={`w-4 h-4 bg-white rounded-full shadow-sm transition-transform duration-300 ${formData.gapYear ? 'translate-x-6' : ''}`} />
                </div>
                <span className="text-sm font-medium text-neutral-700">Interested in a Gap Year?</span>
              </div>

              {/* Submit */}
              <button 
                type="submit"
                className="w-full bg-red-600 text-white font-bold text-lg py-4 rounded-xl hover:bg-red-700 active:scale-[0.99] transition-all duration-200 shadow-lg shadow-red-600/20"
              >
                Analyze my options
              </button>

            </form>
          </div>
        ) : (
          /* Success Step */
          <div className="p-8 md:p-12 flex flex-col items-center text-center animate-in fade-in slide-in-from-bottom-4 duration-500 overflow-y-auto">
            <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6 shadow-sm shrink-0">
              <Check size={28} strokeWidth={3} />
            </div>
            <h3 className="text-3xl font-bold text-neutral-900 mb-2">You're all set!</h3>
            <p className="text-neutral-500 mb-8">We've analyzed your profile.</p>
            
            {/* Highlighted Recommendation Box */}
            <div className="bg-white border border-neutral-200 rounded-2xl p-6 md:p-8 mb-8 w-full max-w-lg shadow-[0_8px_30px_rgb(0,0,0,0.06)] relative overflow-hidden shrink-0 group hover:shadow-[0_8px_30px_rgb(0,0,0,0.12)] transition-shadow duration-500">
               <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-red-600 to-red-500"></div>
              
              <p className="text-xs font-bold uppercase tracking-widest text-neutral-400 mb-4">Your Recommended Focus</p>
              
              <p className="text-3xl md:text-4xl font-black text-neutral-900 tracking-tight mb-2">
                 {formData.role === 'Coach' ? 'Coaching Pathway' : 'College & Development'}
              </p>
              
              <div className="text-sm font-medium text-neutral-400 mb-6">
                 Based on your goal: <span className="text-neutral-900">{formData.goals[0] || 'Player Development'}</span>
              </div>

              {/* The Why Section */}
              <div className="bg-neutral-50 rounded-xl p-5 text-left border border-neutral-100">
                <p className="text-sm text-neutral-600 leading-relaxed">
                  <span className="font-bold text-neutral-900 block mb-1">Why this fits you:</span>
                  {formData.role === 'Coach' 
                    ? "Getting licensed in Germany while gaining practical experience solves the 'lack of access' problem many coaches face. This pathway builds immediate credibility."
                    : "This route addresses the common risk of 'all-or-nothing' trials. It provides a high-level competitive environment while securing your long-term future through education or structured development."
                  }
                </p>
              </div>
            </div>

            <p className="text-sm text-neutral-400 mb-8 max-w-sm mx-auto">
              A WARUBI expert will review your details and reach out to <span className="font-semibold text-neutral-900">{formData.email}</span> shortly with specific examples.
            </p>
            <button 
              onClick={onClose}
              className="px-8 py-3 bg-neutral-900 text-white rounded-xl font-medium hover:bg-black transition-colors shadow-xl shadow-neutral-900/10 shrink-0"
            >
              Back to Pathways
            </button>
          </div>
        )}
      </div>
    </div>
  );
};