import React, { ReactNode } from 'react';

interface SectionProps {
  id?: string;
  children: ReactNode;
  className?: string;
  lightBackground?: boolean;
}

export const Section: React.FC<SectionProps> = ({ id, children, className = "", lightBackground = false }) => {
  return (
    <section 
      id={id} 
      className={`py-20 md:py-32 px-6 md:px-12 lg:px-24 w-full ${lightBackground ? 'bg-neutral-50' : 'bg-white'} ${className}`}
    >
      <div className="max-w-7xl mx-auto">
        {children}
      </div>
    </section>
  );
};