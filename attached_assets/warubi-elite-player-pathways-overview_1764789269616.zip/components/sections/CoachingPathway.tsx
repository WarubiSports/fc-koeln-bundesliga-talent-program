import React from 'react';
import { Section } from '../ui/Section';
import { VideoCard } from '../ui/VideoCard';

export const CoachingPathway: React.FC = () => {
  return (
    <Section id="coaching" lightBackground>
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        
        <div className="lg:col-span-7">
          <VideoCard
            title="UEFA Coaching Story"
            caption="Coaches progressing through UEFA and German FA licenses with WARUBI support."
            thumbnailUrl="https://img.youtube.com/vi/kP3KuKfHYKs/maxresdefault.jpg"
            youtubeId="kP3KuKfHYKs"
          />
        </div>

        <div className="lg:col-span-5 pl-0 lg:pl-12">
          <span className="text-xs font-semibold uppercase tracking-widest text-neutral-400 mb-4 block">
            Pathway 03
          </span>
          <h2 className="text-3xl md:text-4xl font-light text-neutral-900 mb-6">
            UEFA & German FA Coaching Pathway
          </h2>
          <p className="text-lg text-neutral-500 font-light mb-8">
             How coaches use WARUBI to gain licenses and real-world experience.
          </p>
          
          <ul className="space-y-4">
            {[
              "Access to UEFA C and B license opportunities.",
              "German FA education integration and internships.",
              "Connecting coaching development back to player pathways."
            ].map((item, idx) => (
              <li key={idx} className="flex items-start gap-3">
                 <span className="mt-1 w-1.5 h-1.5 rounded-full bg-neutral-300 shrink-0"></span>
                <span className="text-neutral-600 font-light">{item}</span>
              </li>
            ))}
          </ul>
        </div>

      </div>
    </Section>
  );
};