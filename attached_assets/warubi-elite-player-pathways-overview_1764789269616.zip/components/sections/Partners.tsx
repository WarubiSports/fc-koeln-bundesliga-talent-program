import React from 'react';
import { Section } from '../ui/Section';

const PartnerLogo: React.FC = () => (
  <div className="h-16 bg-neutral-100 flex items-center justify-center grayscale opacity-60 hover:opacity-100 transition-opacity duration-300">
     <div className="w-8 h-8 bg-neutral-300 rounded-full"></div>
     <div className="ml-2 w-20 h-3 bg-neutral-300 rounded-sm"></div>
  </div>
);

export const Partners: React.FC = () => {
  return (
    <Section id="partners">
      <h3 className="text-center text-sm font-semibold uppercase tracking-widest text-neutral-400 mb-12">
        Trusted Partners
      </h3>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-8">
        <PartnerLogo />
        <PartnerLogo />
        <PartnerLogo />
        <PartnerLogo />
        <PartnerLogo />
        <PartnerLogo />
        <PartnerLogo />
        <PartnerLogo />
        <PartnerLogo />
        <PartnerLogo />
      </div>
    </Section>
  );
};