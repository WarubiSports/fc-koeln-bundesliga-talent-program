import React from 'react';
import { ShieldCheck, Award, GraduationCap, CheckCircle2 } from 'lucide-react';

export const Credibility = () => {
  return (
    <div className="w-full mb-12 md:mb-16">
      <div className="bg-white rounded-3xl border border-neutral-100 shadow-[0_8px_30px_rgba(0,0,0,0.04)] p-6 md:p-10 flex flex-col xl:flex-row items-center justify-between gap-8 xl:gap-12 relative overflow-hidden">
        
        {/* Background Decoration */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-neutral-50 rounded-full -translate-y-1/2 translate-x-1/2 -z-10" />

        {/* Left: Authority Statement */}
        <div className="flex items-start gap-5 w-full xl:w-auto">
          <div className="w-14 h-14 rounded-2xl bg-neutral-900 flex items-center justify-center shrink-0 shadow-lg shadow-neutral-900/20 text-white">
             <ShieldCheck size={28} strokeWidth={2} />
          </div>
          <div>
            <h3 className="text-xl font-bold text-neutral-900 leading-tight">
              Verified Elite Agency
            </h3>
            <p className="text-sm text-neutral-500 font-medium mt-1 leading-relaxed max-w-sm">
              Official partner for players and coaches. Bridging the gap between German football and global opportunities since 2012.
            </p>
          </div>
        </div>

        {/* Center: Trust Badges */}
        <div className="flex flex-wrap justify-center gap-3 md:gap-4 w-full xl:w-auto">
           <Badge icon={<Award size={16} />} label="UEFA Licensed" color="text-blue-600" bg="bg-blue-50" border="border-blue-100" />
           <Badge icon={<GraduationCap size={16} />} label="NCAA Certified" color="text-red-600" bg="bg-red-50" border="border-red-100" />
           <Badge icon={<CheckCircle2 size={16} />} label="DFB Network" color="text-emerald-600" bg="bg-emerald-50" border="border-emerald-100" />
        </div>

        {/* Right: Key Stats */}
        <div className="flex items-center gap-8 md:gap-12 border-t xl:border-t-0 xl:border-l border-neutral-100 pt-6 xl:pt-0 xl:pl-12 w-full xl:w-auto justify-around xl:justify-end">
           <Stat number="10+" label="Years" />
           <Stat number="500+" label="Placed" />
           <Stat number="100%" label="Transparency" />
        </div>

      </div>
    </div>
  );
};

const Badge = ({ icon, label, color, bg, border }: { icon: React.ReactNode, label: string, color: string, bg: string, border: string }) => (
  <div className={`flex items-center gap-2 px-4 py-2.5 rounded-full border ${bg} ${border} ${color} transition-transform hover:scale-105`}>
    {icon}
    <span className="text-xs font-bold uppercase tracking-wide">{label}</span>
  </div>
);

const Stat = ({ number, label }: { number: string, label: string }) => (
  <div className="text-center">
    <div className="text-2xl md:text-3xl font-black text-neutral-900 tracking-tight leading-none mb-1">{number}</div>
    <div className="text-[10px] font-bold uppercase tracking-widest text-neutral-400">{label}</div>
  </div>
);
