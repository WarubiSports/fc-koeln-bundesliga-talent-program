import React from 'react';
import { ArrowRight } from 'lucide-react';

interface NavTileProps {
  title: string;
  targetId: string;
  label: string;
}

const NavTile: React.FC<NavTileProps> = ({ title, targetId, label }) => (
  <a 
    href={`#${targetId}`}
    className="group block p-8 bg-neutral-50 hover:bg-neutral-100 transition-colors duration-500 border border-neutral-100 hover:border-neutral-200 h-full flex flex-col justify-between min-h-[200px]"
  >
    <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400 group-hover:text-neutral-600 transition-colors">
      {label}
    </span>
    <div className="mt-auto">
      <h3 className="text-xl md:text-2xl font-light text-neutral-900 mb-2 group-hover:translate-x-1 transition-transform duration-300">
        {title}
      </h3>
      <div className="w-full h-[1px] bg-neutral-200 mt-6 group-hover:bg-neutral-300 transition-colors relative overflow-hidden">
        <div className="absolute inset-0 bg-neutral-900 -translate-x-full group-hover:translate-x-0 transition-transform duration-500 ease-out w-full h-full opacity-20" />
      </div>
    </div>
  </a>
);

export const Hero: React.FC = () => {
  return (
    <div className="min-h-[90vh] flex flex-col justify-center px-6 md:px-12 lg:px-24 py-24 relative overflow-hidden">
      <div className="max-w-7xl mx-auto w-full">
        <div className="max-w-3xl mb-16 md:mb-24">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-light tracking-tight text-neutral-900 mb-8 leading-[1.1]">
            WARUBI Elite <br/>
            Player Pathways
          </h1>
          <p className="text-xl md:text-2xl font-light text-neutral-500 leading-relaxed max-w-2xl">
            Real examples of how players and coaches move between Europe, Germany, and US college soccer.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          <NavTile 
            title="College Pathway" 
            targetId="college" 
            label="Watch stories" 
          />
          <NavTile 
            title="Development Europe" 
            targetId="europe" 
            label="See environment" 
          />
          <NavTile 
            title="Coaching Pathway" 
            targetId="coaching" 
            label="Learn more" 
          />
          <NavTile 
            title="Exposure Pathway" 
            targetId="exposure" 
            label="View events" 
          />
        </div>
      </div>
    </div>
  );
};