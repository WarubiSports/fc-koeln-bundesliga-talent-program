import React from 'react';
import { Section } from '../ui/Section';
import { VideoCard } from '../ui/VideoCard';

export const EuropePathway: React.FC = () => {
  return (
    <Section id="europe">
      <div className="mb-16 md:mb-20 max-w-3xl">
        <span className="text-xs font-semibold uppercase tracking-widest text-neutral-400 mb-4 block">
          Pathway 02
        </span>
        <h2 className="text-3xl md:text-4xl font-light text-neutral-900 mb-4">
          Development Europe Pathway
        </h2>
        <p className="text-lg text-neutral-500 font-light">
          Training and playing environments in Germany and Europe.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 mb-16">
        <VideoCard
          title="ITP - International Talent Program"
          caption="Full season development in Cologne with WARUBI and partners."
          thumbnailUrl="https://img.youtube.com/vi/dyiMulYAzdo/maxresdefault.jpg"
          youtubeId="dyiMulYAzdo"
        />
        <VideoCard
          title="Carte Dresden"
          caption="Example of a European development environment and pathway."
          thumbnailUrl="https://img.youtube.com/vi/OCRN38sLIVU/maxresdefault.jpg"
          youtubeId="OCRN38sLIVU"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-8 border-t border-neutral-100">
        <div className="space-y-2">
          <h4 className="font-medium text-neutral-900">Long-term Focus</h4>
          <p className="text-sm text-neutral-500 font-light leading-relaxed">
            Prioritizing player growth over short-term results in established European environments.
          </p>
        </div>
        <div className="space-y-2">
          <h4 className="font-medium text-neutral-900">Holistic Integration</h4>
          <p className="text-sm text-neutral-500 font-light leading-relaxed">
            Seamlessly combining high-level training, competitive games, and daily life in Germany.
          </p>
        </div>
        <div className="space-y-2">
          <h4 className="font-medium text-neutral-900">Future Connections</h4>
          <p className="text-sm text-neutral-500 font-light leading-relaxed">
            Building bridges to professional opportunities or university placements worldwide.
          </p>
        </div>
      </div>
    </Section>
  );
};