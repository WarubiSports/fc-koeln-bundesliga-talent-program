import React from 'react';
import { Section } from '../ui/Section';

export const Contact: React.FC = () => {
  return (
    <Section id="contact" lightBackground className="border-t border-neutral-100">
      <div className="max-w-2xl mx-auto text-center">
        <h2 className="text-3xl font-light text-neutral-900 mb-6">Reach out to us</h2>
        <p className="text-neutral-500 font-light mb-10 leading-relaxed">
          If you are a player, parent, coach, or club and want to understand how these pathways might apply to you, we are here to help.
        </p>
        
        <form className="space-y-4 text-left bg-white p-8 md:p-12 shadow-sm border border-neutral-100">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Name</label>
            <input type="text" className="w-full bg-neutral-50 border border-neutral-200 px-4 py-3 text-neutral-900 focus:outline-none focus:border-neutral-400 transition-colors" placeholder="Your name" />
          </div>
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Email</label>
            <input type="email" className="w-full bg-neutral-50 border border-neutral-200 px-4 py-3 text-neutral-900 focus:outline-none focus:border-neutral-400 transition-colors" placeholder="your@email.com" />
          </div>
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Role</label>
            <select className="w-full bg-neutral-50 border border-neutral-200 px-4 py-3 text-neutral-900 focus:outline-none focus:border-neutral-400 transition-colors appearance-none">
              <option>Player</option>
              <option>Parent</option>
              <option>Coach</option>
              <option>Club Representative</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Message</label>
            <textarea className="w-full bg-neutral-50 border border-neutral-200 px-4 py-3 text-neutral-900 focus:outline-none focus:border-neutral-400 transition-colors h-32 resize-none" placeholder="How can we help?"></textarea>
          </div>
          <button type="button" className="w-full bg-neutral-900 text-white font-medium py-4 hover:bg-black transition-colors">
            Send Message
          </button>
        </form>

        <div className="mt-12 text-sm text-neutral-400">
          &copy; {new Date().getFullYear()} WARUBI Sports. All rights reserved.
        </div>
      </div>
    </Section>
  );
};