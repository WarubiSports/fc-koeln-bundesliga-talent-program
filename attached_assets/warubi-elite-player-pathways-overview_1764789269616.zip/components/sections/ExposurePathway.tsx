import React from 'react';
import { Section } from '../ui/Section';
import { VideoCard } from '../ui/VideoCard';

const ExposureCard: React.FC<{ title: string; desc: string; image: string }> = ({ title, desc, image }) => (
  <div className="group flex flex-col h-full bg-neutral-50 border border-neutral-100 hover:border-neutral-200 transition-colors duration-300">
    <div className="h-72 overflow-hidden bg-neutral-200 relative">
      <img 
        src={image} 
        alt={title} 
        className="w-full h-full object-cover opacity-90 transition-transform duration-1000 ease-out group-hover:scale-105" 
      />
      <div className="absolute inset-0 bg-neutral-900/0 group-hover:bg-neutral-900/10 transition-colors duration-500" />
    </div>
    <div className="p-8 flex flex-col grow">
      <h3 className="text-xl font-medium text-neutral-900 mb-3">{title}</h3>
      <p className="text-neutral-500 font-light leading-relaxed">{desc}</p>
    </div>
  </div>
);

export const ExposurePathway: React.FC = () => {
  return (
    <Section id="exposure">
      <div className="mb-16 md:mb-20 max-w-3xl">
        <span className="text-xs font-semibold uppercase tracking-widest text-neutral-400 mb-4 block">
          Pathway 04
        </span>
        <h2 className="text-3xl md:text-4xl font-light text-neutral-900 mb-4">
          Exposure Pathway
        </h2>
        <p className="text-lg text-neutral-500 font-light">
          Showcases and camps used to create real opportunities for talent identification.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <VideoCard
          title="Showcase Cologne"
          caption="High level event in Cologne with European scouts and US college coaches following via live stream and data analytics."
          thumbnailUrl="https://img.youtube.com/vi/BPwV72OJbdE/maxresdefault.jpg"
          youtubeId="BPwV72OJbdE"
        />
        <ExposureCard 
          title="Camps and ID Events in the USA"
          desc="Selected players join immersive camps or ID events in the USA to be seen live by college and professional coaches."
          image="https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=2940&auto=format&fit=crop"
        />
      </div>
    </Section>
  );
};