import React from 'react';

const moves = [
  "Lukas M. — Cologne to NCAA D1",
  "Sarah K. — Regional League to NCAA D2",
  "Matteo R. — ITP Cologne to US JUCO",
  "Coach David — UEFA B License Acquired",
  "Felix B. — U19 Bundesliga to NAIA",
  "Jonas W. — Showcase Cologne to D1 Offer",
  "Amelie S. — Bayernliga to NCAA D1",
  "ITP Cohort '23 — 100% Placement Rate"
];

export const Ticker: React.FC = () => {
  return (
    <div className="w-full bg-white border-y border-neutral-100 py-6 overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-6 mb-4">
        <h3 className="text-xs font-semibold uppercase tracking-widest text-neutral-400">Recent Moves</h3>
      </div>
      <div className="relative w-full flex overflow-hidden whitespace-nowrap">
        <div className="animate-marquee flex gap-12 items-center">
          {/* Duplicate list to ensure seamless loop */}
          {[...moves, ...moves, ...moves].map((move, idx) => (
            <span key={idx} className="text-lg font-light text-neutral-600 inline-block">
              {move}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};