import React from 'react';
import { Section } from '../ui/Section';
import { VideoCard } from '../ui/VideoCard';
import { Check } from 'lucide-react';

export const CollegePathway: React.FC = () => {
  return (
    <Section id="college" lightBackground>
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-24">
        
        {/* Left Side: Content */}
        <div className="lg:col-span-5 flex flex-col justify-center">
          <span className="text-xs font-semibold uppercase tracking-widest text-neutral-400 mb-4">
            Pathway 01
          </span>
          <h2 className="text-3xl md:text-4xl font-light text-neutral-900 mb-6">
            College Pathway
          </h2>
          <p className="text-lg text-neutral-500 font-light mb-10 leading-relaxed">
            Examples of players using WARUBI to reach US college soccer with a focus on sustainable development.
          </p>
          
          <ul className="space-y-6">
            {[
              "Realistic placement based on athletic and academic fit.",
              "Direct pathways from German academies into NCAA & NAIA.",
              "Long-term support structure throughout the degree."
            ].map((item, idx) => (
              <li key={idx} className="flex items-start gap-3">
                <span className="mt-1 w-5 h-5 rounded-full border border-neutral-300 flex items-center justify-center shrink-0">
                  <Check className="w-3 h-3 text-neutral-600" />
                </span>
                <span className="text-neutral-600 font-light">{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Right Side: Videos */}
        <div className="lg:col-span-7 space-y-12">
          <VideoCard
            title="Avery - College Pathway Story"
            caption="From Europe to US college - how Avery navigated the process."
            thumbnailUrl="https://img.youtube.com/vi/26iGcbEljI8/maxresdefault.jpg"
            youtubeId="26iGcbEljI8"
          />
          <VideoCard
            title="Julian Hodel - College Pathway Story"
            caption="Insights into the journey from Germany to the US."
            thumbnailUrl="https://img.youtube.com/vi/BBKyjHTpmu4/maxresdefault.jpg"
            youtubeId="BBKyjHTpmu4"
          />
        </div>

      </div>
    </Section>
  );
};