import React, { useState } from 'react';
import Header from './components/Header';
import PlayerInputForm from './components/PlayerInputForm';
import AnalysisResultView from './components/AnalysisResult';
import { PlayerProfile, AnalysisResult } from './types';
import { analyzePlayerProfile } from './services/geminiService';
import { AlertCircle } from 'lucide-react';

const App: React.FC = () => {
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFormSubmit = async (profile: PlayerProfile) => {
    setIsLoading(true);
    setError(null);
    try {
      // Scroll to top
      window.scrollTo({ top: 0, behavior: 'smooth' });
      const data = await analyzePlayerProfile(profile);
      setResult(data);
    } catch (err) {
      console.error(err);
      setError("Failed to generate analysis. Please verify your API key and try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setResult(null);
    setError(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-emerald-500/30">
      <Header />

      <main className="container mx-auto px-4 py-8">
        {error && (
          <div className="max-w-4xl mx-auto mb-6 p-4 bg-red-900/20 border border-red-500/50 rounded-lg flex items-center gap-3 text-red-200">
            <AlertCircle className="h-5 w-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {!result ? (
          <div className="animate-fade-in-up">
             <PlayerInputForm onSubmit={handleFormSubmit} isLoading={isLoading} />
          </div>
        ) : (
          <AnalysisResultView result={result} onReset={handleReset} />
        )}
      </main>
    </div>
  );
};

export default App;
