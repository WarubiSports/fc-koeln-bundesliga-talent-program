
import React, { useState } from 'react';
import { PlayerProfile, Position, Gender, SeasonStat } from '../types';
import { ChevronRight, AlertCircle, Plus, Trash2, X } from 'lucide-react';
import { COLLEGE_TEAMS } from '../constants';

interface PlayerInputFormProps {
  onSubmit: (profile: PlayerProfile) => void;
  isLoading: boolean;
}

const HONOR_OPTIONS = [
  "All-Conference (Honorable Mention)",
  "All-Conference (2nd Team)",
  "All-Conference (1st Team)",
  "All-Region",
  "All-American",
  "Conference Player of the Year",
  "National Player of the Year"
];

const initialProfile: PlayerProfile = {
  player_name: "",
  gender: Gender.Male,
  position: [Position.CM], // Initialized as array
  height_cm: 175,
  weight_kg: 70,
  
  current_college_level: "NCAA D2",
  current_college_team: "",
  eligibility_remaining_years: 2,

  stats_history: [
    {
      season: "2024",
      team: "",
      games_played: 0,
      games_started: 0,
      minutes: 0,
      goals: 0,
      assists: 0,
      honors: []
    }
  ],

  physical: {
    forty_yard_dash_s: undefined,
    vertical_jump_in: undefined,
    yo_yo_test_level: undefined,
  },
  academics: {
    gpa_unweighted: 3.0,
    is_grad_student: false,
  },
  video: {
    has_full_game: false,
    has_highlight_reel: false,
  }
};

const PlayerInputForm: React.FC<PlayerInputFormProps> = ({ onSubmit, isLoading }) => {
  const [profile, setProfile] = useState<PlayerProfile>(initialProfile);

  const handleChange = (section: keyof PlayerProfile, field: string, value: any) => {
    setProfile(prev => {
        if (typeof prev[section] === 'object' && prev[section] !== null && !Array.isArray(prev[section])) {
             return {
                ...prev,
                [section]: {
                    ...(prev[section] as object),
                    [field]: value
                }
            }
        }
        return {
            ...prev,
            [section]: value
        }
    });
  };

  const handleTopLevelChange = (field: keyof PlayerProfile, value: any) => {
    setProfile(prev => ({ ...prev, [field]: value }));
  };

  // --- Position Handlers ---
  const addPosition = (posStr: string) => {
    if (!posStr) return;
    const pos = posStr as Position;
    setProfile(prev => {
        if (prev.position.length >= 3 || prev.position.includes(pos)) return prev;
        return { ...prev, position: [...prev.position, pos] };
    });
  };

  const removePosition = (pos: Position) => {
    setProfile(prev => {
        // Prevent removing the last position if you want to enforce at least one, 
        // but usually allowing delete to empty is fine as long as validation checks it (or just simple UX).
        // If we want to allow empty temporarily:
        return { ...prev, position: prev.position.filter(p => p !== pos) };
    });
  };

  // --- Stats History Handlers ---
  const handleStatChange = (index: number, field: keyof SeasonStat, value: any) => {
    const newStats = [...profile.stats_history];
    newStats[index] = { ...newStats[index], [field]: value };
    setProfile(prev => ({ ...prev, stats_history: newStats }));
  };

  const addHonor = (index: number, honor: string) => {
    if (!honor) return;
    const newStats = [...profile.stats_history];
    const currentHonors = newStats[index].honors || [];
    if (!currentHonors.includes(honor)) {
        newStats[index] = { ...newStats[index], honors: [...currentHonors, honor] };
        setProfile(prev => ({ ...prev, stats_history: newStats }));
    }
  };

  const removeHonor = (index: number, honor: string) => {
    const newStats = [...profile.stats_history];
    const currentHonors = newStats[index].honors || [];
    newStats[index] = { ...newStats[index], honors: currentHonors.filter(h => h !== honor) };
    setProfile(prev => ({ ...prev, stats_history: newStats }));
  };

  const addSeason = () => {
    setProfile(prev => ({
      ...prev,
      stats_history: [
        ...prev.stats_history,
        { 
            season: "", 
            team: prev.current_college_team, 
            games_played: 0, 
            games_started: 0, 
            minutes: 0, 
            goals: 0, 
            assists: 0, 
            honors: [] 
        }
      ]
    }));
  };

  const removeSeason = (index: number) => {
    if (profile.stats_history.length <= 1) return;
    const newStats = profile.stats_history.filter((_, i) => i !== index);
    setProfile(prev => ({ ...prev, stats_history: newStats }));
  };
  // ----------------------------

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Basic validation: Ensure at least one position is selected
    if (profile.position.length === 0) {
        alert("Please select at least one position.");
        return;
    }
    onSubmit(profile);
  };

  const inputClass = "mt-1 block w-full rounded-md border-slate-700 bg-slate-900 text-white shadow-sm focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm py-2 px-3";
  const labelClass = "block text-xs font-medium text-slate-400 uppercase tracking-wide mb-1";
  const sectionClass = "bg-slate-800/50 p-6 rounded-xl border border-slate-700 space-y-4";

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-4xl mx-auto p-4">
      
      {/* Datalist for Team Autocomplete */}
      <datalist id="college-list">
        {COLLEGE_TEAMS.map((team, idx) => (
            <option key={idx} value={team} />
        ))}
      </datalist>

      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">Transfer Portal Eval</h2>
        <p className="text-slate-400">Entering the portal? See where you actually fit before you jump.</p>
      </div>

      {/* Personal & Eligibility */}
      <div className={sectionClass}>
        <h3 className="text-lg font-semibold text-emerald-450 flex items-center gap-2">
            1. Eligibility & Context
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <label className={labelClass}>Full Name</label>
                <input type="text" required className={inputClass} value={profile.player_name} onChange={(e) => handleTopLevelChange('player_name', e.target.value)} />
            </div>
            <div>
                <label className={labelClass}>Gender</label>
                <select className={inputClass} value={profile.gender} onChange={(e) => handleTopLevelChange('gender', e.target.value)}>
                    {Object.values(Gender).map(g => <option key={g} value={g}>{g}</option>)}
                </select>
            </div>
            <div>
                <label className={labelClass}>Positions (Max 3)</label>
                <div className="flex flex-wrap gap-2 mb-2 min-h-[32px]">
                    {profile.position.map((pos, idx) => (
                        <span key={idx} className="inline-flex items-center gap-1 bg-slate-700 text-white text-xs font-semibold px-2.5 py-1 rounded-full border border-slate-600">
                            {pos}
                            <button type="button" onClick={() => removePosition(pos)} className="hover:text-red-400 transition-colors">
                                <X className="w-3 h-3" />
                            </button>
                        </span>
                    ))}
                    {profile.position.length === 0 && (
                         <span className="text-slate-500 text-xs italic py-1.5">No position selected</span>
                    )}
                </div>
                {profile.position.length < 3 && (
                    <select 
                        className={inputClass} 
                        value="" 
                        onChange={(e) => addPosition(e.target.value)}
                    >
                        <option value="">+ Add Position...</option>
                        {Object.values(Position).filter(p => !profile.position.includes(p)).map(p => (
                            <option key={p} value={p}>{p}</option>
                        ))}
                    </select>
                )}
            </div>
             <div>
                <label className={labelClass}>Current College Level</label>
                <select className={inputClass} value={profile.current_college_level} onChange={(e) => handleTopLevelChange('current_college_level', e.target.value)}>
                    <option value="NCAA D1">NCAA D1</option>
                    <option value="NCAA D2">NCAA D2</option>
                    <option value="NCAA D3">NCAA D3</option>
                    <option value="NAIA">NAIA</option>
                    <option value="NJCAA (JUCO)">NJCAA (JUCO)</option>
                    <option value="CCC (California JUCO)">CCC (Cal JUCO)</option>
                </select>
            </div>
            <div>
                <label className={labelClass}>Current Team Name</label>
                <input 
                    type="text" 
                    list="college-list"
                    placeholder="e.g. State University" 
                    className={inputClass} 
                    value={profile.current_college_team} 
                    onChange={(e) => handleTopLevelChange('current_college_team', e.target.value)} 
                />
            </div>
            <div>
                <label className={labelClass}>Eligibility Remaining</label>
                <select className={inputClass} value={profile.eligibility_remaining_years} onChange={(e) => handleTopLevelChange('eligibility_remaining_years', Number(e.target.value))}>
                    <option value={4}>4 Years</option>
                    <option value={3}>3 Years</option>
                    <option value={2}>2 Years</option>
                    <option value={1}>1 Year (COVID/Grad)</option>
                </select>
            </div>
        </div>
      </div>

      {/* Production Stats - Multi-season */}
      <div className={sectionClass}>
        <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-emerald-450 flex items-center gap-2">
                2. Verified Collegiate Stats
            </h3>
            <button type="button" onClick={addSeason} className="text-xs flex items-center gap-1 bg-slate-700 hover:bg-slate-600 text-white px-3 py-1.5 rounded-md transition-colors">
                <Plus className="w-3 h-3" /> Add Season
            </button>
        </div>
        
        <div className="p-3 bg-blue-900/20 border border-blue-500/30 rounded-lg flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
            <div className="text-xs text-blue-200 space-y-1">
                <p>Transfers are recruited on <strong>production</strong>. Coaches want to see starts and minutes.</p>
                <p className="opacity-80">Please add all available stats. If you are a junior, list all 3 seasons including team names.</p>
            </div>
        </div>

        <div className="space-y-4">
            {profile.stats_history.map((stat, index) => (
                <div key={index} className="bg-slate-900/40 p-4 rounded-lg border border-slate-700 relative animate-fade-in">
                    <div className="flex justify-between items-center mb-3 pb-2 border-b border-slate-700/50">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Season Entry #{index + 1}</span>
                        {profile.stats_history.length > 1 && (
                            <button type="button" onClick={() => removeSeason(index)} className="text-red-400 hover:text-red-300 text-xs flex items-center gap-1 px-2 py-1 rounded hover:bg-red-900/20 transition-colors">
                                <Trash2 className="w-3 h-3" /> Remove
                            </button>
                        )}
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="col-span-1">
                            <label className={labelClass}>Season / Year</label>
                            <input 
                                type="text" 
                                placeholder="e.g. 2024 (Jr)" 
                                className={inputClass} 
                                value={stat.season} 
                                onChange={(e) => handleStatChange(index, 'season', e.target.value)} 
                            />
                        </div>
                        <div className="col-span-1">
                            <label className={labelClass}>Team Name</label>
                            <input 
                                type="text" 
                                list="college-list"
                                placeholder="Team Name" 
                                className={inputClass} 
                                value={stat.team} 
                                onChange={(e) => handleStatChange(index, 'team', e.target.value)} 
                            />
                        </div>
                        <div>
                            <label className={labelClass}>Games Played</label>
                            <input type="number" className={inputClass} value={stat.games_played} onChange={(e) => handleStatChange(index, 'games_played', Number(e.target.value))} />
                        </div>
                        <div>
                            <label className={labelClass}>Games Started</label>
                            <input type="number" className={inputClass} value={stat.games_started} onChange={(e) => handleStatChange(index, 'games_started', Number(e.target.value))} />
                        </div>
                        <div>
                            <label className={labelClass}>Total Minutes</label>
                            <input type="number" className={inputClass} value={stat.minutes} onChange={(e) => handleStatChange(index, 'minutes', Number(e.target.value))} />
                        </div>
                        <div>
                            <label className={labelClass}>Goals</label>
                            <input type="number" className={inputClass} value={stat.goals} onChange={(e) => handleStatChange(index, 'goals', Number(e.target.value))} />
                        </div>
                        <div>
                            <label className={labelClass}>Assists</label>
                            <input type="number" className={inputClass} value={stat.assists} onChange={(e) => handleStatChange(index, 'assists', Number(e.target.value))} />
                        </div>
                        <div className="col-span-2 md:col-span-1">
                            <label className={labelClass}>Honors / Awards</label>
                            <div className="space-y-2">
                                <div className="flex flex-wrap gap-2 min-h-[24px]">
                                    {stat.honors && stat.honors.length > 0 ? (
                                        stat.honors.map((honor, hIdx) => (
                                            <span key={hIdx} className="inline-flex items-center gap-1 bg-emerald-500/20 text-emerald-300 text-[10px] leading-tight px-2 py-1 rounded border border-emerald-500/30">
                                                {honor}
                                                <button type="button" onClick={() => removeHonor(index, honor)} className="hover:text-white transition-colors">
                                                    <X className="w-3 h-3" />
                                                </button>
                                            </span>
                                        ))
                                    ) : (
                                        <span className="text-slate-600 text-xs italic py-1">No awards selected</span>
                                    )}
                                </div>
                                <select 
                                    className={inputClass} 
                                    value="" 
                                    onChange={(e) => addHonor(index, e.target.value)}
                                >
                                    <option value="">+ Add Award...</option>
                                    {HONOR_OPTIONS.filter(opt => !stat.honors?.includes(opt)).map(opt => (
                                        <option key={opt} value={opt}>{opt}</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            ))}
            <button type="button" onClick={addSeason} className="w-full py-2 border-2 border-dashed border-slate-700 rounded-lg text-slate-400 hover:border-emerald-500 hover:text-emerald-500 transition-all flex items-center justify-center gap-2 text-sm font-medium">
                <Plus className="w-4 h-4" /> Add Another Season
            </button>
        </div>
      </div>

      {/* Physical */}
      <div className={sectionClass}>
        <h3 className="text-lg font-semibold text-emerald-450 flex items-center gap-2">
            3. Physical & Video
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <label className={labelClass}>Height (cm)</label>
                <input type="number" className={inputClass} value={profile.height_cm} onChange={(e) => handleTopLevelChange('height_cm', Number(e.target.value))} />
            </div>
            <div>
                <label className={labelClass}>Weight (kg)</label>
                <input type="number" className={inputClass} value={profile.weight_kg} onChange={(e) => handleTopLevelChange('weight_kg', Number(e.target.value))} />
            </div>
            <div>
                <label className={labelClass}>40 Yd Dash (s)</label>
                <input type="number" step="0.01" placeholder="e.g. 4.8" className={inputClass} 
                    value={profile.physical.forty_yard_dash_s || ''} 
                    onChange={(e) => handleChange('physical', 'forty_yard_dash_s', e.target.value ? Number(e.target.value) : undefined)} 
                />
            </div>
        </div>
        <div className="flex items-center gap-4 mt-4 pt-4 border-t border-slate-700">
            <label className="flex items-center space-x-2 text-sm text-slate-300">
                <input type="checkbox" className="rounded border-slate-700 text-emerald-500 focus:ring-emerald-500 bg-slate-900"
                    checked={profile.video.has_highlight_reel}
                    onChange={(e) => handleChange('video', 'has_highlight_reel', e.target.checked)}
                />
                <span>I have a recent highlight reel</span>
            </label>
            <label className="flex items-center space-x-2 text-sm text-slate-300">
                <input type="checkbox" className="rounded border-slate-700 text-emerald-500 focus:ring-emerald-500 bg-slate-900"
                    checked={profile.video.has_full_game}
                    onChange={(e) => handleChange('video', 'has_full_game', e.target.checked)}
                />
                <span>I have full game footage from college</span>
            </label>
        </div>
      </div>

      {/* Academic & Transfer Status */}
      <div className={sectionClass}>
        <h3 className="text-lg font-semibold text-emerald-450 flex items-center gap-2">
            4. Academic Transfer Status
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label className={labelClass}>Transfer GPA</label>
                <input type="number" step="0.1" className={inputClass} value={profile.academics.gpa_unweighted} onChange={(e) => handleChange('academics', 'gpa_unweighted', Number(e.target.value))} />
            </div>
            <div className="flex items-center h-full pt-6">
                 <label className="flex items-center space-x-2 text-sm text-slate-300">
                    <input type="checkbox" className="rounded border-slate-700 text-emerald-500 focus:ring-emerald-500 bg-slate-900"
                        checked={profile.academics.is_grad_student}
                        onChange={(e) => handleChange('academics', 'is_grad_student', e.target.checked)}
                    />
                    <span>I will be a Graduate Transfer</span>
                </label>
            </div>
        </div>
      </div>

      <div className="pt-4">
        <button
            type="submit"
            disabled={isLoading}
            className={`w-full flex justify-center items-center py-4 px-4 border border-transparent rounded-md shadow-sm text-lg font-bold text-slate-900 bg-emerald-450 hover:bg-emerald-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-all ${isLoading ? 'opacity-75 cursor-not-allowed' : 'hover:scale-[1.01]'}`}
        >
            {isLoading ? (
                <>Analyzing Transfer Value...</>
            ) : (
                <>
                   Run Transfer Check <ChevronRight className="ml-2 h-5 w-5" />
                </>
            )}
        </button>
      </div>
    </form>
  );
};

export default PlayerInputForm;
