import React from 'react';
import { AnalysisResult as AnalysisResultType, Probability } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { AlertTriangle, CheckCircle, TrendingUp, BookOpen, Trophy, Users, Clock, AlertOctagon } from 'lucide-react';

interface AnalysisResultProps {
  result: AnalysisResultType;
  onReset: () => void;
}

const ProbabilityBar: React.FC<{ level: string; data: Probability }> = ({ level, data }) => {
  const getColor = (val: number) => {
    if (val >= 70) return '#10b981'; // emerald-500
    if (val >= 40) return '#f59e0b'; // amber-500
    return '#ef4444'; // red-500
  };

  return (
    <div className="mb-3">
      <div className="flex justify-between text-sm mb-1">
        <span className="font-bold text-slate-200">{level}</span>
        <span className="text-slate-400 uppercase text-xs">{data.label} ({data.chance_percent}%)</span>
      </div>
      <div className="w-full bg-slate-800 rounded-full h-3">
        <div 
          className="h-3 rounded-full transition-all duration-1000" 
          style={{ width: `${data.chance_percent}%`, backgroundColor: getColor(data.chance_percent) }}
        />
      </div>
    </div>
  );
};

const AnalysisResult: React.FC<AnalysisResultProps> = ({ result, onReset }) => {

  const chartData = [
    { name: 'D1', value: result.probabilities.D1.chance_percent, label: result.probabilities.D1.label },
    { name: 'D2', value: result.probabilities.D2.chance_percent, label: result.probabilities.D2.label },
    { name: 'D3', value: result.probabilities.D3.chance_percent, label: result.probabilities.D3.label },
    { name: 'NAIA', value: result.probabilities.NAIA.chance_percent, label: result.probabilities.NAIA.label },
    { name: 'JUCO', value: result.probabilities.JUCO.chance_percent, label: result.probabilities.JUCO.label },
  ];

  const getBarColor = (val: number) => {
    if (val >= 70) return '#10b981';
    if (val >= 40) return '#f59e0b';
    return '#ef4444'; 
  };

  return (
    <div className="max-w-5xl mx-auto p-4 space-y-8 animate-fade-in">
      
      {/* Headline */}
      <div className="bg-slate-800/80 border-l-4 border-emerald-500 p-6 rounded-r-lg shadow-lg backdrop-blur-sm">
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-2">"{result.headline}"</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Probabilities Chart */}
        <div className="lg:col-span-2 bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl">
          <h3 className="text-lg font-semibold text-slate-200 mb-6 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-emerald-450" /> Recruiting Probabilities
          </h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#334155" />
                <XAxis type="number" domain={[0, 100]} hide />
                <YAxis dataKey="name" type="category" stroke="#94a3b8" width={40} tick={{fill: '#94a3b8', fontSize: 14, fontWeight: 'bold'}} />
                <Tooltip 
                    cursor={{fill: '#1e293b'}}
                    contentStyle={{backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc'}}
                />
                <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={30}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={getBarColor(entry.value)} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 grid grid-cols-5 gap-2 text-center text-xs text-slate-500">
             {chartData.map((d) => (
                <div key={d.name} className="bg-slate-800/50 p-2 rounded">
                    <div className="font-bold text-slate-300">{d.name}</div>
                    <div className={`${d.label === 'very low' ? 'text-red-500' : d.label === 'high' ? 'text-emerald-500' : 'text-amber-500'}`}>{d.label}</div>
                </div>
             ))}
          </div>
        </div>

        {/* Market Snapshot */}
        <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl flex flex-col justify-between">
          <div>
             <h3 className="text-lg font-semibold text-slate-200 mb-4 flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-400" /> Coach's Eye View
             </h3>
             <div className="space-y-4">
                <div className="p-3 bg-slate-800/50 rounded-lg border border-slate-700/50">
                    <div className="text-xs text-slate-400 uppercase font-bold mb-1">Athletic</div>
                    <p className="text-sm text-slate-200 leading-relaxed">{result.coach_view.athletic_snapshot}</p>
                </div>
                <div className="p-3 bg-slate-800/50 rounded-lg border border-slate-700/50">
                    <div className="text-xs text-slate-400 uppercase font-bold mb-1">Technical</div>
                    <p className="text-sm text-slate-200 leading-relaxed">{result.coach_view.technical_snapshot}</p>
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* Strengths & Risks */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-900/50 p-6 rounded-xl border border-emerald-900/30">
          <h3 className="text-lg font-semibold text-emerald-400 mb-4 flex items-center gap-2">
            <CheckCircle className="w-5 h-5" /> Verified Strengths
          </h3>
          <ul className="space-y-3">
            {result.biggest_strengths.map((str, i) => (
              <li key={i} className="flex items-start gap-3 text-slate-300 text-sm">
                <span className="mt-1.5 w-1.5 h-1.5 bg-emerald-500 rounded-full shrink-0" />
                {str}
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-slate-900/50 p-6 rounded-xl border border-red-900/30">
          <h3 className="text-lg font-semibold text-red-400 mb-4 flex items-center gap-2">
            <AlertOctagon className="w-5 h-5" /> Critical Risks
          </h3>
          <ul className="space-y-3">
            {result.biggest_risks.map((risk, i) => (
              <li key={i} className="flex items-start gap-3 text-slate-300 text-sm">
                <span className="mt-1.5 w-1.5 h-1.5 bg-red-500 rounded-full shrink-0" />
                {risk}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* 90 Day Plan */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl">
        <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-amber-400" /> 90-Day Improvement Plan
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {result.priority_improvements_90_days.map((item, idx) => (
                <div key={idx} className="bg-slate-800 p-5 rounded-lg border-t-2 border-amber-500/50 hover:bg-slate-800/80 transition-colors">
                    <div className="text-xs text-amber-400 uppercase font-bold mb-2">{item.area}</div>
                    <div className="font-semibold text-white mb-2 h-12 line-clamp-2">{item.issue}</div>
                    <div className="text-sm text-slate-300 mb-3">
                        <span className="text-slate-500 block text-xs mb-1">Goal:</span>
                        {item.target}
                    </div>
                    <div className="text-xs text-slate-400 border-t border-slate-700 pt-3 mt-auto">
                        <span className="font-bold text-slate-300">Plan:</span> {item.plan}
                    </div>
                </div>
            ))}
        </div>
      </div>

      {/* Actions Tabs / List */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5 text-purple-400" /> Immediate Action Items
        </h3>
        <div className="space-y-6">
            <div>
                <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-3">This Month</h4>
                <div className="grid gap-2">
                    {result.recommended_actions.this_month.map((action, i) => (
                        <div key={i} className="flex items-center gap-3 bg-slate-800/40 p-3 rounded border border-slate-700">
                            <div className="w-6 h-6 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-400 text-xs font-bold shrink-0">{i + 1}</div>
                            <span className="text-slate-200 text-sm">{action}</span>
                        </div>
                    ))}
                </div>
            </div>
             <div className="grid md:grid-cols-2 gap-6 pt-4 border-t border-slate-800">
                <div>
                    <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-3">Recruiting Tactics</h4>
                    <ul className="space-y-2">
                        {result.recommended_actions.recruiting_tactics.map((t, i) => (
                             <li key={i} className="text-sm text-slate-300 pl-4 border-l-2 border-slate-700 py-1">{t}</li>
                        ))}
                    </ul>
                </div>
                <div>
                    <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-3">Season Focus</h4>
                    <ul className="space-y-2">
                        {result.recommended_actions.this_season.map((t, i) => (
                             <li key={i} className="text-sm text-slate-300 pl-4 border-l-2 border-slate-700 py-1">{t}</li>
                        ))}
                    </ul>
                </div>
             </div>
        </div>
      </div>

      {result.missing_or_uncertain_data.length > 0 && (
        <div className="bg-slate-800/30 p-4 rounded border border-slate-700">
            <h4 className="text-xs text-slate-500 uppercase font-bold mb-2 flex items-center gap-2">
                <AlertTriangle className="w-3 h-3" /> Missing Data Affecting Accuracy
            </h4>
            <div className="flex flex-wrap gap-2">
                {result.missing_or_uncertain_data.map((d, i) => (
                    <span key={i} className="text-xs bg-slate-900 text-slate-400 px-2 py-1 rounded">{d}</span>
                ))}
            </div>
        </div>
      )}

      <div className="flex justify-center pt-8 pb-12">
        <button onClick={onReset} className="text-slate-400 hover:text-white underline decoration-slate-600 underline-offset-4 transition-colors">
            Analyze Another Player
        </button>
      </div>
    </div>
  );
};

export default AnalysisResult;
