import React from 'react';
import { Activity } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-450/10 p-2 rounded-lg">
              <Activity className="h-6 w-6 text-emerald-450" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight">
                Transfer<span className="text-emerald-450">Engine</span>
              </h1>
              <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">College Soccer Reality Check</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;