import { GoogleGenAI } from "@google/genai";
import { PlayerProfile, AnalysisResult } from "../types";
import { SYSTEM_PROMPT } from "../constants";

export const analyzePlayerProfile = async (profile: PlayerProfile): Promise<AnalysisResult> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key not found. Please check your environment variables.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: JSON.stringify(profile),
      config: {
        systemInstruction: SYSTEM_PROMPT,
        responseMimeType: "application/json",
        temperature: 0.4, // Lower temperature for more analytical/factual output
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("Received empty response from AI.");
    }

    const result: AnalysisResult = JSON.parse(text);
    return result;

  } catch (error) {
    console.error("Error analyzing profile:", error);
    throw error;
  }
};
