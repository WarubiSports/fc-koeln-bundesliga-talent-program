export enum Position {
    GK = "GK",
    CB = "CB",
    FB = "FB",
    CDM = "CDM",
    CM = "CM",
    CAM = "CAM",
    Winger = "Winger",
    ST = "ST"
  }
  
  export enum Gender {
    Male = "male",
    Female = "female"
  }

  export type CollegeLevel = "NCAA D1" | "NCAA D2" | "NCAA D3" | "NAIA" | "NJCAA (JUCO)" | "CCC (California JUCO)";
  
  export interface SeasonStat {
    season: string; // e.g. "2024 (Junior)"
    team: string;
    games_played: number;
    games_started: number;
    minutes: number;
    goals: number;
    assists: number;
    clean_sheets?: number;
    honors: string[];
  }
  
  export interface PlayerProfile {
    player_name: string;
    gender: Gender;
    position: Position[]; // Changed to array to support multiple positions
    height_cm: number;
    weight_kg: number;
    
    // Transfer specific context
    current_college_level: CollegeLevel;
    current_college_team: string;
    eligibility_remaining_years: number;
    
    // Production history (Array for multiple seasons)
    stats_history: SeasonStat[];

    physical: {
      forty_yard_dash_s?: number;
      vertical_jump_in?: number;
      yo_yo_test_level?: number;
    };

    academics: {
      gpa_unweighted: number; // Transfer GPA
      is_grad_student: boolean;
    };

    video: {
      has_full_game: boolean;
      has_highlight_reel: boolean;
    };
  }
  
  export interface Probability {
    chance_percent: number;
    label: "high" | "medium" | "low" | "very low";
  }
  
  export interface ImprovementPlan {
    area: string;
    issue: string;
    target: string;
    plan: string;
    expected_impact: string;
  }
  
  export interface AnalysisResult {
    headline: string;
    probabilities: {
      D1: Probability;
      D2: Probability;
      D3: Probability;
      NAIA: Probability;
      JUCO: Probability;
    };
    coach_view: {
      athletic_snapshot: string;
      technical_snapshot: string;
      academic_snapshot: string;
      market_snapshot: string;
    };
    biggest_strengths: string[];
    biggest_risks: string[];
    priority_improvements_90_days: ImprovementPlan[];
    recommended_actions: {
      this_month: string[];
      this_season: string[];
      recruiting_tactics: string[];
    };
    missing_or_uncertain_data: string[];
  }